import React, { useState } from 'react';
import {
  View, Text, StyleSheet, Pressable, ScrollView, Image,
  TextInput, Platform, Alert, SafeAreaView
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { VideoView, useVideoPlayer } from 'expo-video';
import * as ImagePicker from 'expo-image-picker';

const STARTER_VIDEOS = [
  {
    id: '1',
    user: 'pixelcraft',
    caption: 'Buduję bazę na nowym świecie! 🏡',
    likes: 128,
    source: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4'
  },
  {
    id: '2',
    user: 'vyro_gamer',
    caption: 'Który pomysł na kolejny odcinek?',
    likes: 84,
    source: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4'
  }
];

function VideoCard({ item, liked, onLike }) {
  const player = useVideoPlayer(item.source, p => { p.loop = true; });
  return (
    <View style={styles.videoCard}>
      <VideoView player={player} style={styles.video} contentFit="cover" nativeControls />
      <View style={styles.videoShade}>
        <View style={styles.creatorRow}>
          <View style={styles.avatar}><Text style={styles.avatarText}>{item.user[0].toUpperCase()}</Text></View>
          <Text style={styles.username}>@{item.user}</Text>
          <Pressable style={styles.follow}><Text style={styles.followText}>Obserwuj</Text></Pressable>
        </View>
        <Text style={styles.caption}>{item.caption}</Text>
      </View>
      <View style={styles.actions}>
        <Pressable onPress={onLike} style={styles.action}>
          <Text style={[styles.actionIcon, liked && { color: '#ff4f86' }]}>{liked ? '♥' : '♡'}</Text>
          <Text style={styles.actionLabel}>{item.likes + (liked ? 1 : 0)}</Text>
        </Pressable>
        <Pressable style={styles.action} onPress={() => Alert.alert('Komentarze', 'Komentarze dodamy po podłączeniu bazy danych.')}>
          <Text style={styles.actionIcon}>◯</Text><Text style={styles.actionLabel}>Komentuj</Text>
        </Pressable>
        <Pressable style={styles.action} onPress={() => Alert.alert('Udostępnianie', 'Udostępnianie będzie dostępne w kolejnej wersji.')}>
          <Text style={styles.actionIcon}>↗</Text><Text style={styles.actionLabel}>Udostępnij</Text>
        </Pressable>
      </View>
    </View>
  );
}

export default function App() {
  const [tab, setTab] = useState('Dla Ciebie');
  const [liked, setLiked] = useState({});
  const [videos, setVideos] = useState(STARTER_VIDEOS);
  const [decor, setDecor] = useState('✨ Neonowy');
  const [profileName, setProfileName] = useState('Nowy twórca');

  const addVideo = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Brak dostępu', 'Zezwól aplikacji na dostęp do galerii, aby wybrać film.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['videos'],
      allowsEditing: false,
      quality: 1
    });
    if (!result.canceled && result.assets?.[0]?.uri) {
      setVideos(current => [{
        id: String(Date.now()),
        user: 'ty',
        caption: 'Mój nowy film 🎬',
        likes: 0,
        source: result.assets[0].uri
      }, ...current]);
      setTab('Dla Ciebie');
      Alert.alert('Dodano lokalnie', 'Film pojawił się w tym podglądzie. Publikowanie dla innych wymaga podłączenia serwera.');
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <Text style={styles.logo}>VYRO<Text style={styles.dot}>.</Text></Text>
        <Text style={styles.headerTag}>VIDEO COMMUNITY</Text>
      </View>

      {tab === 'Dla Ciebie' || tab === 'Obserwowani' ? (
        <ScrollView style={styles.feed} contentContainerStyle={styles.feedContent}>
          <View style={styles.feedTabs}>
            {['Dla Ciebie', 'Obserwowani'].map(t => (
              <Pressable key={t} onPress={() => setTab(t)}>
                <Text style={[styles.feedTab, tab === t && styles.feedTabActive]}>{t}</Text>
              </Pressable>
            ))}
          </View>
          {videos.map(item => (
            <VideoCard key={item.id} item={item} liked={!!liked[item.id]}
              onLike={() => setLiked(v => ({ ...v, [item.id]: !v[item.id] }))} />
          ))}
          <Text style={styles.footerNote}>To wersja startowa VYRO • przykładowe filmy</Text>
        </ScrollView>
      ) : tab === 'Profil' ? (
        <ScrollView contentContainerStyle={styles.profile}>
          <View style={styles.profileAvatar}><Text style={styles.profileAvatarText}>V</Text></View>
          <Text style={styles.profileTitle}>Twój profil</Text>
          <TextInput value={profileName} onChangeText={setProfileName} style={styles.input} placeholder="Nazwa profilu" placeholderTextColor="#777" />
          <Text style={styles.sectionTitle}>Dekoracje jak na Discordzie</Text>
          <Text style={styles.muted}>Wybierz wygląd swojej wizytówki:</Text>
          <View style={styles.decorGrid}>
            {['✨ Neonowy', '🌌 Kosmiczny', '🔥 Ognisty', '🌿 Spokojny'].map(d => (
              <Pressable key={d} onPress={() => setDecor(d)} style={[styles.decor, decor === d && styles.decorSelected]}>
                <Text style={styles.decorText}>{d}</Text>
              </Pressable>
            ))}
          </View>
          <View style={styles.profilePreview}>
            <Text style={styles.previewLabel}>PODGLĄD PROFILU</Text>
            <Text style={styles.previewName}>{profileName || 'Twój profil'}</Text>
            <Text style={styles.previewDecor}>{decor} • VYRO</Text>
            <Text style={styles.muted}>Ramki, odznaki i tła premium dodamy w kolejnej wersji.</Text>
          </View>
        </ScrollView>
      ) : tab === 'Szukaj' ? (
        <View style={styles.profile}>
          <Text style={styles.profileTitle}>Odkrywaj VYRO</Text>
          <TextInput style={styles.input} placeholder="Szukaj filmów i twórców..." placeholderTextColor="#777" />
          <Text style={styles.muted}>Wyszukiwanie zacznie działać po podłączeniu bazy danych.</Text>
        </View>
      ) : (
        <View style={styles.profile}>
          <Text style={styles.profileTitle}>Wiadomości</Text>
          <Text style={styles.muted}>Prywatne wiadomości przygotujemy w kolejnej wersji.</Text>
        </View>
      )}

      <View style={styles.bottomNav}>
        {[
          ['⌂', 'Dla Ciebie'], ['⌕', 'Szukaj'], ['＋', 'Dodaj'], ['✉', 'Wiadomości'], ['◎', 'Profil']
        ].map(([icon, label]) => (
          <Pressable key={label} onPress={() => label === 'Dodaj' ? addVideo() : setTab(label)} style={styles.navItem}>
            <Text style={[styles.navIcon, tab === label && styles.navActive]}>{icon}</Text>
            <Text style={[styles.navLabel, tab === label && styles.navActive]}>{label === 'Dla Ciebie' ? 'Start' : label}</Text>
          </Pressable>
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#090914', paddingTop: Platform.OS === 'android' ? 8 : 0 },
  header: { height: 58, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#222238' },
  logo: { color: '#fff', fontSize: 27, fontWeight: '900', letterSpacing: 3 },
  dot: { color: '#a78bfa' },
  headerTag: { color: '#8b88a5', fontSize: 10, letterSpacing: 2 },
  feed: { flex: 1 },
  feedContent: { paddingBottom: 20 },
  feedTabs: { flexDirection: 'row', justifyContent: 'center', gap: 28, paddingVertical: 15 },
  feedTab: { color: '#77758e', fontSize: 14, fontWeight: '700' },
  feedTabActive: { color: '#fff', borderBottomWidth: 2, borderBottomColor: '#a78bfa', paddingBottom: 5 },
  videoCard: { marginHorizontal: 12, marginBottom: 18, minHeight: 420, borderRadius: 20, overflow: 'hidden', backgroundColor: '#17172a', position: 'relative' },
  video: { width: '100%', height: 440, backgroundColor: '#17172a' },
  videoShade: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 16, backgroundColor: 'rgba(5,5,15,0.58)' },
  creatorRow: { flexDirection: 'row', alignItems: 'center', gap: 9, marginBottom: 10 },
  avatar: { width: 34, height: 34, borderRadius: 17, backgroundColor: '#7656c9', alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#fff', fontWeight: '900' },
  username: { color: '#fff', fontWeight: '800' },
  follow: { borderWidth: 1, borderColor: '#c4b5fd', borderRadius: 16, paddingHorizontal: 12, paddingVertical: 5 },
  followText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  caption: { color: '#fff', fontSize: 14 },
  actions: { position: 'absolute', right: 12, top: 110, gap: 18, alignItems: 'center' },
  action: { alignItems: 'center', gap: 3 },
  actionIcon: { color: '#fff', fontSize: 27, fontWeight: '700' },
  actionLabel: { color: '#fff', fontSize: 10 },
  footerNote: { textAlign: 'center', color: '#77758e', padding: 14, fontSize: 11 },
  bottomNav: { height: 68, borderTopWidth: 1, borderTopColor: '#222238', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', backgroundColor: '#0d0d1b' },
  navItem: { alignItems: 'center', minWidth: 55 },
  navIcon: { color: '#77758e', fontSize: 23 },
  navLabel: { color: '#77758e', fontSize: 9, marginTop: 2 },
  navActive: { color: '#c4b5fd' },
  profile: { flexGrow: 1, alignItems: 'center', padding: 24, gap: 14 },
  profileAvatar: { width: 92, height: 92, borderRadius: 46, backgroundColor: '#7656c9', alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: '#c4b5fd' },
  profileAvatarText: { color: '#fff', fontSize: 38, fontWeight: '900' },
  profileTitle: { color: '#fff', fontSize: 24, fontWeight: '900' },
  input: { width: '100%', maxWidth: 420, color: '#fff', backgroundColor: '#19192b', borderWidth: 1, borderColor: '#34344e', borderRadius: 12, padding: 14 },
  sectionTitle: { color: '#fff', fontSize: 17, fontWeight: '800', marginTop: 18 },
  muted: { color: '#8d8ba4', textAlign: 'center', fontSize: 12 },
  decorGrid: { width: '100%', maxWidth: 420, flexDirection: 'row', flexWrap: 'wrap', gap: 9, justifyContent: 'center' },
  decor: { padding: 12, borderRadius: 12, backgroundColor: '#19192b', borderWidth: 1, borderColor: '#34344e' },
  decorSelected: { borderColor: '#a78bfa', backgroundColor: '#282044' },
  decorText: { color: '#fff', fontWeight: '700' },
  profilePreview: { width: '100%', maxWidth: 420, padding: 20, borderRadius: 18, backgroundColor: '#211b38', alignItems: 'center', gap: 9, marginTop: 10 },
  previewLabel: { color: '#a78bfa', fontSize: 10, letterSpacing: 2, fontWeight: '800' },
  previewName: { color: '#fff', fontSize: 23, fontWeight: '900' },
  previewDecor: { color: '#d8ccff', fontWeight: '700' }
});
