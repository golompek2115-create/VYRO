# VYRO — wersja startowa

VYRO to prototyp aplikacji społecznościowej z krótkimi filmami, przygotowany jako wspólny projekt dla Androida i przeglądarki na komputerze.

## Co działa w prototypie
- ekran pionowego feedu z przykładowymi filmami,
- odtwarzanie filmów,
- lokalne polubienia,
- wybór filmu z galerii urządzenia (film pojawia się tylko lokalnie w bieżącej sesji),
- profil z edytowalną nazwą i wyborem dekoracji,
- podstawowa nawigacja.

## Czego jeszcze nie ma
To nie jest jeszcze publiczna sieć społecznościowa. Konta, logowanie, trwałe przechowywanie filmów, komentarze, obserwowanie, czaty, moderacja i synchronizacja między urządzeniami wymagają backendu. Nie należy publikować aplikacji jako gotowej platformy, dopóki te elementy i zabezpieczenia nie zostaną wdrożone.

## Uruchomienie
Wymagane: Node.js LTS oraz Expo Go na Androidzie (lub emulator Androida).

1. Rozpakuj archiwum.
2. Otwórz terminal w folderze `VYRO`.
3. Uruchom `npm install`.
4. Uruchom `npx expo start`.
5. Zeskanuj kod QR aplikacją Expo Go albo naciśnij `w`, aby otworzyć wersję webową.

## Plan kolejnych etapów
1. Backend: Supabase (konta, baza danych i bezpieczne przechowywanie filmów).
2. Feed: pobieranie filmów z serwera i paginacja.
3. Profile: avatary, banery, ramki, odznaki, tła i dekoracje.
4. Społeczność: komentarze, obserwowanie, powiadomienia i wiadomości.
5. Bezpieczeństwo: zgłaszanie treści, blokowanie użytkowników, moderacja, limity i ustawienia prywatności.
6. Publikacja: testy Androida i wdrożenie strony.

## Ważne
Nie umieszczaj kluczy administracyjnych ani haseł w aplikacji mobilnej. Połączenie z backendem powinno używać publicznego klucza klienta i reguł bezpieczeństwa po stronie bazy.
